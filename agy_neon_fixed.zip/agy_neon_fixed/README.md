# AGY Neon model discovery fix

**What changed:** the previous code sent `User-Agent: antigravity`, which can cause Cloud Code to return a stale model catalog with every quota at 100%. This version uses a CLI-shaped User-Agent based on the local OS and AGY CLI 1.5.15. The OAuth session/token store path is unchanged. Existing login remains valid.

```bash
python3 cli.py models --all
python3 cli.py models --diagnose
```

`--diagnose` compares three server catalog results: daily with the full User-Agent, daily with the legacy `antigravity` User-Agent, and production with the full User-Agent. It prints **only counts and the Neon/Hydrogen IDs**, not tokens, project IDs or full account responses.

If the default still lacks Neon, compare those results to `agy models` on the same account. Google documents Neon for paid Google AI Pro / Ultra and certain eligible premium-device trials; it may be absent due to entitlement or rollout issues. Do not assume a model is available because it appears in the binary.

Override the UA if you know your actual official CLI value:

```bash
AGY_USER_AGENT='antigravity/cli/1.5.15 (aidev_client; os_type=linux; arch=amd64; auth_method=consumer)' python3 cli.py models --all
```

Cloud Code endpoint remains `https://daily-cloudcode-pa.googleapis.com` by default. You can override `AGY_CLOUDCODE_URL` for a specific host. Existing stored sessions are in `~/.config/agy_direct_review/tokens.json` unless overridden by `AGY_PY_STORE`.

**Important:** this patch does not prove that the server grants Neon access or accepts generation requests. The diagnostic is read-only model discovery. The build does not redistribute a vendor OAuth client secret; to perform a new login, use credentials from your own OAuth registration via `AGY_OAUTH_CLIENT_SECRET`.

Tests:
```bash
python3 -m unittest discover -s tests -v
```
