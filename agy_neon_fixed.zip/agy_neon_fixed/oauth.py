"""Browser OAuth PKCE + confidential client secret for the agy registration.

The client secret is the one extracted from the official agy binary and
verified against Google's token endpoint (invalid-code probe returned
invalid_grant, not invalid_client — credentials accepted). Google's error on
the no-secret exchange was the final confirmation: HTTP 400 invalid_request
"Missing required parameter: client_secret" means this OAuth client
registration requires a confidential exchange.
"""
import base64
import hashlib
import json
import os
import secrets
import time
import urllib.parse
import urllib.request
import urllib.error
import webbrowser
from pathlib import Path

AUTH_URL = 'https://accounts.google.com/o/oauth2/auth'
TOKEN_URL = 'https://oauth2.googleapis.com/token'
REDIRECT = 'https://antigravity.google/oauth-callback'
SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/cclog',
    'https://www.googleapis.com/auth/experimentsandconfigs',
    'https://www.googleapis.com/auth/aicode',
    'openid',
]
STORE = Path(os.environ.get('AGY_PY_STORE', '~/.config/agy_direct_review/tokens.json')).expanduser()


class OAuthError(RuntimeError):
    pass


OAUTH_HINTS = {
    'invalid_client': 'Google rejected the OAuth client registration. Check whether this client supports a public PKCE token exchange; omitting a required client secret is not sufficient.',
    'invalid_grant': 'The code may be expired, already redeemed, or bound to another redirect URI, OAuth client, or PKCE verifier. Start a fresh login; never reuse an earlier code.',
    'redirect_uri_mismatch': 'The redirect_uri must match the one used to issue the authorization code and the registered OAuth client.',
    'invalid_request': 'The token request parameters or client authentication method were rejected.',
    'unauthorized_client': 'This OAuth client is not authorized to use the requested flow.',
}


def safe_error_detail(description):
    """Report a missing OAuth parameter without exposing server-returned secrets.

    The raw error_description may contain user data, so only known parameter
    names and missing/required markers are allowed into terminal output.
    """
    if not isinstance(description, str):
        return ''
    import re
    field = re.search(r'\b(client_secret|client_id|redirect_uri|grant_type|code_verifier|code)\b', description, re.I)
    if field and re.search(r'\b(missing|required|must be provided|not provided)\b', description, re.I):
        return f'Missing required OAuth parameter: {field.group(1).lower()}.'
    return ''


def post_form(url, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/x-www-form-urlencoded'})
    try:
        with urllib.request.urlopen(req, timeout=30) as res:
            return json.load(res)
    except urllib.error.HTTPError as e:
        # Token-endpoint errors usually have a JSON body. Report the *error type*,
        # not authorization codes, refresh tokens, headers, or full callback URLs.
        try:
            response = json.loads(e.read().decode('utf-8'))
        except (UnicodeError, ValueError):
            response = {}
        error = response.get('error', 'unknown_error')
        if not isinstance(error, str) or not error.replace('_', '').isalnum():
            error = 'unknown_error'
        hint = OAUTH_HINTS.get(error, 'The OAuth token endpoint rejected the request.')
        detail = safe_error_detail(response.get('error_description', ''))
        raise OAuthError(f'Google OAuth HTTP {e.code}: {error}. {detail or hint}') from None


def save_tokens(tokens):
    STORE.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(STORE.parent, 0o700)
    # Atomic replacement, owner-readable only.
    temp = STORE.with_suffix('.tmp')
    with temp.open('w', encoding='utf-8') as f:
        os.chmod(temp, 0o600)
        json.dump(tokens, f)
    os.replace(temp, STORE)


def read_tokens():
    return json.loads(STORE.read_text(encoding='utf-8'))


def pkce():
    verifier = base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip('=')
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
    return verifier, challenge


def oauth_url(client_id, state, challenge):
    params = {
        'client_id': client_id,
        'response_type': 'code',
        'redirect_uri': REDIRECT,
        'scope': ' '.join(SCOPES),
        'access_type': 'offline',
        'prompt': 'consent',
        'state': state,
        'code_challenge': challenge,
        'code_challenge_method': 'S256',
    }
    return AUTH_URL + '?' + urllib.parse.urlencode(params)


def parse_return(value, state):
    value = value.strip()
    if value.startswith(('http://', 'https://')):
        parsed = urllib.parse.urlparse(value)
        if parsed.scheme != 'https' or parsed.netloc != 'antigravity.google' or parsed.path != '/oauth-callback':
            raise ValueError('Unexpected OAuth callback origin')
        q = urllib.parse.parse_qs(parsed.query)
        if q.get('state', [None])[0] != state:
            raise ValueError('OAuth state does not match')
        if 'error' in q:
            raise ValueError('OAuth returned an error: ' + q['error'][0])
        code = q.get('code', [None])[0]
        if not code:
            raise ValueError('Callback URL contains no authorization code')
        return code
    # Google's hosted callback may show only a code. PKCE still binds the code
    # to the verifier; state can only be checked when a full callback is pasted.
    if not value or any(c.isspace() for c in value):
        raise ValueError('Paste the authorization code or complete callback URL')
    return value


"""Browser OAuth PKCE + confidential client secret for the agy registration.

The client secret is the one extracted from the official agy binary and
verified against Google's token endpoint (invalid-code probe returned
invalid_grant, not invalid_client — credentials accepted). Google's error on
the no-secret exchange was the final confirmation: HTTP 400 invalid_request
"Missing required parameter: client_secret" means this OAuth client
registration requires a confidential exchange.
"""


def login(client_id, client_secret=''):
    verifier, challenge = pkce()
    state = secrets.token_urlsafe(24)
    url = oauth_url(client_id, state, challenge)
    print('Open this URL in your browser:\n' + url + '\n')
    webbrowser.open(url)
    returned = input('Paste complete redirect URL (preferred) or authorization code: ')
    code = parse_return(returned, state)
    exchange = {
        'grant_type': 'authorization_code',
        'client_id': client_id,
        'redirect_uri': REDIRECT,
        'code': code,
        'code_verifier': verifier,
    }
    if client_secret:
        # Confidential client: Google rejects the exchange without the secret
        # (HTTP 400 invalid_request "Missing required parameter: client_secret").
        exchange['client_secret'] = client_secret
    result = post_form(TOKEN_URL, exchange)
    if not result.get('access_token'):
        raise RuntimeError('OAuth exchange returned no access token')
    result['expires_at'] = time.time() + int(result.get('expires_in', 3600))
    result['client_id'] = client_id
    # Persist the secret only inside the 0600 token store so refreshes work
    # after restarts; it is never printed.
    if client_secret:
        result['client_secret'] = client_secret
    save_tokens(result)
    print('OAuth token saved locally (0600), refresh token: ' + ('yes' if result.get('refresh_token') else 'no'))


def access_token():
    tokens = read_tokens()
    if time.time() < tokens.get('expires_at', 0) - 60:
        return tokens['access_token']
    if not tokens.get('refresh_token'):
        raise RuntimeError('No refresh token available; repeat login')
    data = post_form(TOKEN_URL, {
        'grant_type': 'refresh_token',
        'refresh_token': tokens['refresh_token'],
        'client_id': tokens['client_id'],
        'client_secret': tokens.get('client_secret', ''),
    })
    tokens.update(data)
    tokens['expires_at'] = time.time() + int(data.get('expires_in', 3600))
    save_tokens(tokens)
    return tokens['access_token']
