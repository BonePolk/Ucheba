import importlib
import io
import json
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import oauth
import cloudcode


class FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class Tests(unittest.TestCase):
    def test_pkce_format(self):
        verifier, challenge = oauth.pkce()
        self.assertGreaterEqual(len(verifier), 43)
        self.assertEqual(len(challenge), 43)
        q = parse_qs(urlsplit(oauth.oauth_url('public-app', 'state', challenge)).query)
        self.assertEqual(q['code_challenge_method'], ['S256'])
        self.assertEqual(q['state'], ['state'])

    def test_check_callback_state(self):
        code = oauth.parse_return('https://antigravity.google/oauth-callback?state=abc&code=xyz', 'abc')
        self.assertEqual(code, 'xyz')
        with self.assertRaises(ValueError):
            oauth.parse_return('https://antigravity.google/oauth-callback?state=bad&code=xyz', 'abc')

    def test_correct_cloudcode_envelope(self):
        data = cloudcode.payload('hello', 'model-id')
        self.assertEqual(data['request']['contents'][0]['parts'][0]['text'], 'hello')
        self.assertEqual(data['project'], cloudcode.PROJECT)
        self.assertEqual(data['model'], 'model-id')

    def test_authorization_headers_and_route(self):
        def fake_urlopen(req, timeout=0):
            self.assertEqual(req.full_url, cloudcode.BASE + '/v1internal:generateContent')
            self.assertEqual(req.get_header('Authorization'), 'Bearer sample-token')
            self.assertEqual(json.loads(req.data)['request']['contents'][0]['role'], 'user')
            return FakeResponse(b'{"response":{"candidates":[{"content":{"parts":[{"text":"hello"}]}}]}}')
        with patch('urllib.request.urlopen', fake_urlopen):
            out = cloudcode.request('/v1internal:generateContent', cloudcode.payload('hey', 'model-id'), 'sample-token')
        self.assertEqual(cloudcode.text_from_response(out), 'hello')

    def test_token_exchange_includes_client_secret_when_provided(self):
        with patch('oauth.post_form') as post, patch('oauth.webbrowser.open'), patch('builtins.input', return_value='example-code'), patch('oauth.save_tokens'):
            post.return_value = {'access_token': 'fake', 'expires_in': 60, 'refresh_token': 'fake-refresh'}
            oauth.login('agy-app', 'GOCSPX-test-secret')
            data = post.call_args.args[1]
            self.assertEqual(data['client_secret'], 'GOCSPX-test-secret')
            self.assertIn('code_verifier', data)
            self.assertEqual(data['grant_type'], 'authorization_code')

    def test_token_exchange_omits_client_secret_when_not_provided(self):
        with patch('oauth.post_form') as post, patch('oauth.webbrowser.open'), patch('builtins.input', return_value='example-code'), patch('oauth.save_tokens'):
            post.return_value = {'access_token': 'fake', 'expires_in': 60, 'refresh_token': 'fake-refresh'}
            oauth.login('public-app')
            data = post.call_args.args[1]
            self.assertNotIn('client_secret', data)
            self.assertIn('code_verifier', data)
            self.assertEqual(data['grant_type'], 'authorization_code')

    def test_refresh_grant_carries_client_secret(self):
        with patch('oauth.read_tokens') as read, patch('oauth.post_form') as post, patch('oauth.save_tokens'):
            read.return_value = {'access_token': 'old', 'expires_at': 0, 'refresh_token': 'r', 'client_id': 'agy-app', 'client_secret': 'GOCSPX-test-secret'}
            post.return_value = {'access_token': 'new', 'expires_in': 3600}
            token = oauth.access_token()
            self.assertEqual(token, 'new')
            data = post.call_args.args[1]
            self.assertEqual(data['grant_type'], 'refresh_token')
            self.assertEqual(data['client_secret'], 'GOCSPX-test-secret')

    def test_login_persists_client_secret_in_store(self):
        with patch('oauth.post_form') as post, patch('oauth.webbrowser.open'), patch('builtins.input', return_value='example-code'), patch('oauth.save_tokens') as save:
            post.return_value = {'access_token': 'fake', 'expires_in': 60, 'refresh_token': 'fake-refresh'}
            oauth.login('agy-app', 'GOCSPX-test-secret')
            saved = save.call_args.args[0]
            self.assertEqual(saved['client_secret'], 'GOCSPX-test-secret')
            self.assertEqual(saved['client_id'], 'agy-app')

    def test_oauth_http_error_json_is_reported_without_secrets(self):
        raw = io.BytesIO(b'{"error":"invalid_client","error_description":"private secret: demo-private-value"}')
        failure = HTTPError(oauth.TOKEN_URL, 400, 'Bad Request', {}, raw)
        with patch('urllib.request.urlopen', side_effect=failure):
            with self.assertRaises(oauth.OAuthError) as raised:
                oauth.post_form(oauth.TOKEN_URL, {'grant_type': 'authorization_code', 'code': 'private-code'})
        msg = str(raised.exception)
        self.assertIn('HTTP 400: invalid_client', msg)
        self.assertNotIn('demo-private-value', msg)
        self.assertNotIn('private-code', msg)

    def test_oauth_invalid_request_missing_client_secret_diagnostic(self):
        raw = io.BytesIO(b'{"error":"invalid_request","error_description":"Missing required parameter: client_secret"}')
        failure = HTTPError(oauth.TOKEN_URL, 400, 'Bad Request', {}, raw)
        with patch('urllib.request.urlopen', side_effect=failure):
            with self.assertRaises(oauth.OAuthError) as raised:
                oauth.post_form(oauth.TOKEN_URL, {'code': 'private-code'})
        self.assertIn('Missing required OAuth parameter: client_secret', str(raised.exception))
        self.assertNotIn('private-code', str(raised.exception))

    def test_oauth_invalid_request_description_redacts_unknown(self):
        raw = io.BytesIO(b'{"error":"invalid_request","error_description":"secret value: do-not-share"}')
        failure = HTTPError(oauth.TOKEN_URL, 400, 'Bad Request', {}, raw)
        with patch('urllib.request.urlopen', side_effect=failure):
            with self.assertRaises(oauth.OAuthError) as raised:
                oauth.post_form(oauth.TOKEN_URL, {'code': 'private-code'})
        self.assertNotIn('do-not-share', str(raised.exception))

    def test_oauth_invalid_grant_advice(self):
        failure = HTTPError(oauth.TOKEN_URL, 400, 'Bad Request', {}, io.BytesIO(b'{"error":"invalid_grant"}'))
        with patch('urllib.request.urlopen', side_effect=failure):
            with self.assertRaises(oauth.OAuthError) as raised:
                oauth.post_form(oauth.TOKEN_URL, {'code': 'private-code'})
        self.assertIn('fresh login', str(raised.exception))

    def test_oauth_non_json_http_error(self):
        failure = HTTPError(oauth.TOKEN_URL, 400, 'Bad Request', {}, io.BytesIO(b'not JSON'))
        with patch('urllib.request.urlopen', side_effect=failure):
            with self.assertRaises(oauth.OAuthError) as raised:
                oauth.post_form(oauth.TOKEN_URL, {'code': 'private-code'})
        self.assertIn('unknown_error', str(raised.exception))


if __name__ == '__main__':
    unittest.main()

class ModelDiscoveryTests(unittest.TestCase):
    def test_project_discovery_and_catalog(self):
        calls = []
        def fake_request(path, data, token):
            calls.append((path, data, token))
            if path.endswith('loadCodeAssist'):
                return {'cloudaicompanionProject': 'projects/user-project-42'}
            return {'models': {'gemini-x': {'displayName': 'Gemini X'}}}
        with patch.object(cloudcode, 'PROJECT', ''), patch.object(cloudcode, 'request', fake_request), patch.object(cloudcode, 'access_token', return_value='test-access-token'):
            result = cloudcode.catalog()
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][1], {'metadata': {'ideType': 'ANTIGRAVITY'}})
        self.assertEqual(calls[1][1], {'project': 'projects/user-project-42'})
        self.assertEqual(result['models']['gemini-x']['displayName'], 'Gemini X')

    def test_project_override_skips_discovery(self):
        with patch.object(cloudcode, 'PROJECT', 'my-project'), patch.object(cloudcode, 'request', return_value={'models': {}}) as req, patch.object(cloudcode, 'access_token', return_value='test'):
            cloudcode.catalog()
        req.assert_called_once_with('/v1internal:fetchAvailableModels', {'project': 'my-project'}, 'test')

    def test_models_parsing_and_picker_order(self):
        response = {
            'models': {
                'a': {'displayName': 'Alpha', 'maxTokens': 100, 'quotaInfo': {'remainingFraction': 0.55, 'resetTime': '2026-11-24T12:00:00Z'}},
                'b': {'displayName': 'Beta'},
                'hidden': {'isInternal': True, 'displayName': 'Hidden'},
            },
            'agentModelSorts': [{'groups': [{'modelIds': ['b', 'a']}]}],
        }
        models = cloudcode.models_from_response(response)
        self.assertEqual([m['id'] for m in models], ['b', 'a'])
        self.assertEqual(models[1]['remaining_fraction'], 0.55)
        self.assertEqual(len(cloudcode.models_from_response(response, include_internal=True)), 3)

    def test_generate_uses_discovered_project(self):
        with patch.object(cloudcode, 'PROJECT', ''), patch.object(cloudcode, 'access_token', return_value='test'), patch.object(cloudcode, 'project_id', return_value='actual-user-project'), patch.object(cloudcode, 'request', return_value={'response': {}}) as req:
            cloudcode.generate('hi', 'gemini-3-flash')
        self.assertEqual(req.call_args.args[1]['project'], 'actual-user-project')

    def test_missing_project_is_actionable(self):
        with patch.object(cloudcode, 'PROJECT', ''), patch.object(cloudcode, 'request', return_value={'currentTier': {}}):
            with self.assertRaisesRegex(RuntimeError, 'loadCodeAssist returned no cloudaicompanionProject'):
                cloudcode.project_id('test')

class HttpTransportTests(unittest.TestCase):
    def test_real_http_envelope_for_project_and_catalog(self):
        calls = []
        def urlopen(req, timeout=0):
            calls.append((req.full_url, json.loads(req.data.decode()), req.get_header('Authorization'), req.get_header('User-agent')))
            if req.full_url.endswith(':loadCodeAssist'):
                return FakeResponse(b'{"cloudaicompanionProject":"user-project"}')
            return FakeResponse(b'{"models":{"gemini-demo":{"displayName":"Demo"}}}')
        with patch.object(cloudcode, 'PROJECT', ''), patch.object(cloudcode, 'access_token', return_value='local-test-token'), patch('urllib.request.urlopen', urlopen):
            data = cloudcode.catalog()
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][1], {'metadata': {'ideType': 'ANTIGRAVITY'}})
        self.assertEqual(calls[1][1], {'project': 'user-project'})
        self.assertEqual(calls[1][2], 'Bearer local-test-token')
        self.assertIn('antigravity/cli/', calls[1][3])
        self.assertEqual(cloudcode.models_from_response(data)[0]['id'], 'gemini-demo')

    def test_server_permission_denied_is_readable(self):
        err = HTTPError('https://example.test', 403, 'Forbidden', {}, io.BytesIO(b'{"error":{"status":"PERMISSION_DENIED","message":"Account not allowed"}}'))
        with patch('urllib.request.urlopen', side_effect=err):
            with self.assertRaisesRegex(RuntimeError, r'Cloud Code 403 PERMISSION_DENIED'):
                cloudcode.request('/v1internal:fetchAvailableModels', {'project': 'p'}, 'sensitive-token')


class NeonTests(unittest.TestCase):
    def test_default_agent_is_full_cli_shape(self):
        with patch.dict('os.environ', {}, clear=True):
            ua = cloudcode.client_user_agent()
        self.assertTrue(ua.startswith('antigravity/cli/'))
        self.assertIn('auth_method=consumer', ua)

    def test_diagnostic_compares_headers_and_hosts(self):
        calls = []
        def fake_request(path, data, token, *, base=None, user_agent=None):
            calls.append((base, user_agent))
            return {'models': {'gemini-4-neon-high': {'displayName': 'Neon'}, 'gemini-4-hydrogen-medium': {'displayName': 'Hydrogen'}}} if user_agent != 'antigravity' else {'models': {'gemini-2.5-flash': {}}}
        with patch.object(cloudcode, 'request', fake_request), patch.object(cloudcode, 'project_id', return_value='project'), patch.object(cloudcode, 'access_token', return_value='token'):
            out = cloudcode.diagnose_models()
        self.assertEqual(len(calls), 3)
        self.assertEqual(out[0]['neon'], ['gemini-4-neon-high'])
        self.assertEqual(out[1]['neon'], [])
        self.assertEqual(out[2]['models'], 2)
