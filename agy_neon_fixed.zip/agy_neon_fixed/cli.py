"""Minimal independent experiment; no external binary or ACP required."""
import argparse
import json
import os
from pathlib import Path
import oauth
from cloudcode import generate, catalog, diagnose_models, models_from_response, text_from_response


def main():
    p = argparse.ArgumentParser()
    commands = p.add_subparsers(dest='cmd', required=True)
    login = commands.add_parser('login')
    login.add_argument('--client-id', default=os.getenv('AGY_OAUTH_CLIENT_ID', '1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com'))
    # Existing saved sessions work without this; for a new login supply your own configured OAuth client credentials.
    login.add_argument('--client-secret', default=os.getenv('AGY_OAUTH_CLIENT_SECRET'))
    commands.add_parser('status')
    models = commands.add_parser('models')
    models.add_argument('--raw', action='store_true', help='print complete server JSON')
    models.add_argument('--json', action='store_true', help='print normalized model list as JSON')
    models.add_argument('--all', action='store_true', help='include internal / hidden model entries')
    models.add_argument('--diagnose', action='store_true', help='compare daily/production catalogs and User-Agent variants (no tokens printed)')
    ask = commands.add_parser('ask')
    ask.add_argument('prompt')
    ask.add_argument('--model', default='gemini-3.5-flash')
    args = p.parse_args()
    if args.cmd == 'login':
        oauth.login(args.client_id, args.client_secret)
    elif args.cmd == 'status':
        if not oauth.STORE.exists():
            print('No saved OAuth session')
        else:
            t = oauth.read_tokens()
            print(json.dumps({
                'stored': True,
                'expires_at': t.get('expires_at'),
                'has_refresh_token': bool(t.get('refresh_token')),
                'scopes': t.get('scope'),
            }, ensure_ascii=False, indent=2))
    elif args.cmd == 'models':
        if args.diagnose:
            print(json.dumps(diagnose_models(), ensure_ascii=False, indent=2))
            return
        response = catalog()
        if args.raw:
            print(json.dumps(response, ensure_ascii=False, indent=2))
        else:
            entries = models_from_response(response, include_internal=args.all)
            if args.json:
                print(json.dumps(entries, ensure_ascii=False, indent=2))
            elif not entries:
                print('No displayable models. Try: python cli.py models --all or --raw')
            else:
                for model in entries:
                    remaining = model['remaining_fraction']
                    quota = f'  {remaining * 100:.0f}% remaining' if remaining is not None else ''
                    reset = f"  reset: {model['reset_time']}" if model['reset_time'] else ''
                    print(f"{model['id']} — {model['name']}{quota}{reset}")
    else:
        result = generate(args.prompt, args.model)
        print(text_from_response(result) or json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (oauth.OAuthError, RuntimeError, ValueError) as e:
        raise SystemExit(str(e)) from None

