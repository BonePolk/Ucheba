"""Cloud Code model discovery and generation using an existing OAuth session."""
import json
import os
import platform
import sys
import urllib.error
import urllib.request
import uuid

from oauth import access_token

BASE = os.environ.get('AGY_CLOUDCODE_URL', 'https://daily-cloudcode-pa.googleapis.com').rstrip('/')
# Empty by default: the real account project is discovered from loadCodeAssist.
PROJECT = os.environ.get('AGY_CLOUDCODE_PROJECT', '').strip()
# A bare "antigravity" User-Agent returns a legacy catalog for some accounts.
# This is the documented CLI-shaped client identifier, not a model override.
def client_user_agent():
    machine = platform.machine().lower()
    arch = {'x86_64': 'amd64', 'aarch64': 'arm64'}.get(machine, machine)
    system = {'linux': 'linux', 'darwin': 'darwin', 'win32': 'windows'}.get(sys.platform, sys.platform)
    version = os.environ.get('AGY_CLI_VERSION', '1.5.15')
    return os.environ.get('AGY_USER_AGENT') or f'antigravity/cli/{version} (aidev_client; os_type={system}; arch={arch}; auth_method=consumer)'



def request(path, data, token, *, base=None, user_agent=None):
    req = urllib.request.Request(
        (base or BASE) + path,
        method='POST',
        data=json.dumps(data).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': user_agent or client_user_agent(),
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as res:
            return json.load(res)
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode('utf-8'))
        except (UnicodeError, ValueError):
            detail = {}
        err = detail.get('error', {}) if isinstance(detail, dict) else {}
        if not isinstance(err, dict):
            err = {}
        # Don't dump raw server responses: they may contain request or account data.
        status = str(err.get('status', 'HTTP_ERROR'))[:64]
        message = str(err.get('message', 'Request rejected'))[:240]
        raise RuntimeError(f'Cloud Code {e.code} {status} at {path}: {message}') from None


def project_id(token):
    if PROJECT:
        return PROJECT
    info = request('/v1internal:loadCodeAssist', {'metadata': {'ideType': 'ANTIGRAVITY'}}, token)
    project = info.get('cloudaicompanionProject') or info.get('response', {}).get('cloudaicompanionProject')
    if isinstance(project, dict):
        project = project.get('id') or project.get('projectId') or project.get('project')
    if not isinstance(project, str) or not project.strip():
        raise RuntimeError('loadCodeAssist returned no cloudaicompanionProject; set AGY_CLOUDCODE_PROJECT if you know your account project')
    return project.strip()


def catalog():
    token = access_token()
    return request('/v1internal:fetchAvailableModels', {'project': project_id(token)}, token)


def payload(prompt, model, project=PROJECT):
    return {
        'project': project,
        'model': model,
        'request': {'contents': [{'role': 'user', 'parts': [{'text': prompt}]}]},
        'userAgent': 'antigravity',
        'requestId': str(uuid.uuid4()),
        'requestType': 'agent',
    }


def generate(prompt, model):
    token = access_token()
    return request('/v1internal:generateContent', payload(prompt, model, project_id(token)), token)


def diagnose_models():
    """Compare server catalogs without printing account data or credentials."""
    token = access_token()
    project = project_id(token)
    current_ua = client_user_agent()
    checks = [
        ('daily / CLI header', 'https://daily-cloudcode-pa.googleapis.com', current_ua),
        ('daily / legacy header', 'https://daily-cloudcode-pa.googleapis.com', 'antigravity'),
        ('production / CLI header', 'https://cloudcode-pa.googleapis.com', current_ua),
    ]
    outcomes = []
    for label, base, ua in checks:
        try:
            body = request('/v1internal:fetchAvailableModels', {'project': project}, token,
                           base=base, user_agent=ua)
            model_map = body.get('models', {})
            all_ids = list(model_map) if isinstance(model_map, dict) else [m.get('id', '') for m in model_map]
            outcomes.append({
                'source': label,
                'models': len(all_ids),
                'neon': sorted(m for m in all_ids if 'neon' in m.lower()),
                'hydrogen': sorted(m for m in all_ids if 'hydrogen' in m.lower()),
            })
        except RuntimeError as exc:
            outcomes.append({'source': label, 'error': str(exc)})
    return outcomes


def models_from_response(body, include_internal=False):
    """Normalize model map and preserve the order in the server picker."""
    models = body.get('models', {})
    if isinstance(models, list):
        models = {m.get('model') or m.get('id'): m for m in models if isinstance(m, dict)}
    if not isinstance(models, dict):
        raise ValueError('Unexpected fetchAvailableModels response: models is not a map')

    picker = []
    for item in body.get('agentModelSorts', []):
        for group in item.get('groups', []):
            picker.extend(group.get('modelIds', []))
    ordered = list(dict.fromkeys([*picker, *models.keys()]))

    result = []
    for model_id in ordered:
        model = models.get(model_id)
        if not isinstance(model, dict):
            continue
        name = model.get('displayName') or ''
        internal = bool(model.get('isInternal')) or not name
        if internal and not include_internal:
            continue
        quota = model.get('quotaInfo') or {}
        fraction = quota.get('remainingFraction')
        if not isinstance(fraction, (int, float)) or isinstance(fraction, bool) or not 0 <= fraction <= 1:
            fraction = None
        result.append({
            'id': model_id,
            'name': name or model_id,
            'remaining_fraction': fraction,
            'reset_time': quota.get('resetTime'),
            'max_tokens': model.get('maxTokens'),
            'max_output_tokens': model.get('maxOutputTokens'),
            'internal': internal,
            'recommended': model_id in picker,
        })
    return result


def text_from_response(body):
    result = body.get('response', body)
    candidates = result.get('candidates', [])
    if not candidates:
        return None
    parts = candidates[0].get('content', {}).get('parts', [])
    return ''.join(p['text'] for p in parts if 'text' in p)
